﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;


namespace MediBlog.Controllers
{

    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private IConfiguration _config;
        private readonly MediBlogContext _mediBlogContext;
        private readonly IMapper _mapper;

        public LoginController(IConfiguration config,
            MediBlogContext mediBlogContext,
            IMapper mapper)
        {
            _config = config;
            _mediBlogContext = mediBlogContext;
            _mapper = mapper;
        }


        [HttpPost]
        [Route("login")]
        public IActionResult Login([FromBody] LoginDto login)
        {
            IActionResult response = Unauthorized();
            var user = AuthenticateUser(login);

            if (user != null)
            {
                var tokenString = GenerateJSONWebToken(user);
                response = Ok(new { token = tokenString });
            }

            return response;
        }

        [HttpPost]
        [Route("signup")]
        public IActionResult SignUp([FromBody] SignUpDto signupdto)
        {
            ResponseDto responseDto = new ResponseDto();

            bool isExistingUser = _mediBlogContext.UserModels.Any(x => (x.EmailAddress == signupdto.EmailAddress || x.PhoneNo == signupdto.PhoneNo));
            if (isExistingUser)
            {
                responseDto = new ResponseDto()
                {
                    ResultCode = HttpStatusCode.BadRequest,
                    Result = JsonConvert.SerializeObject(new { errorMessage = "User already exits" })
                };
                return BadRequest(responseDto);
            };


            UserModel userModel = _mapper.Map<UserModel>(signupdto);

            userModel.CreationTime = DateTime.Now;
            userModel.UpdationTime = DateTime.Now;
            _mediBlogContext.UserModels.Add(userModel);
            _mediBlogContext.SaveChanges();
            

            return Ok(responseDto);
        }

        [HttpPost]
        [Route("forgotpassword")]
        public IActionResult ForGotPassword ([FromBody] ForGotDto forGotDto)
        {
            ResponseDto responseDto = new ResponseDto();

           var dbUser = _mediBlogContext.UserModels.FirstOrDefault(x => x.EmailAddress == forGotDto.EmailAddress || x.PhoneNo == forGotDto.Username);
            if (dbUser!=null) {
                SendSms obj = new SendSms();
                obj.Execute();

                UserModel userModel = _mapper.Map<UserModel>(dbUser);

                userModel.UpdationTime = DateTime.Now;
                _mediBlogContext.UserModels.Update(userModel);
                _mediBlogContext.SaveChanges();
            }
            else {
                return BadRequest(responseDto);
            }

            return Ok(responseDto);
        }
        private string GenerateJSONWebToken(LoginDto userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, userInfo.Username),
                new Claim(JwtRegisteredClaimNames.Email, userInfo.EmailAddress),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddMinutes(20),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private LoginDto AuthenticateUser(LoginDto user)
        {
            var dbUser = _mediBlogContext.UserModels.FirstOrDefault(x => x.PhoneNo == user.Username && x.Password == user.Password);

            return dbUser == null ? null : user;
        }
    }
}
