﻿using System;
using Vonage;
using Vonage.Request;

namespace MediBlog.Controllers
{
	public class SendSms
	{
        public void Execute()
        {
            var TO_NUMBER = "9441276125";
            var VONAGE_BRAND_NAME = "DevTest";
            var VONAGE_API_KEY = "390ccf4d";
            var VONAGE_API_SECRET = "lI0yIKZSIVBqKPer";

            var credentials = Credentials.FromApiKeyAndSecret(
                VONAGE_API_KEY,
                VONAGE_API_SECRET
                );

            var VonageClient = new VonageClient(credentials);

            //var response = VonageClient.SmsClient.SendAnSms(new Vonage.Messaging.SendSmsRequest()
            //{
            //    To = TO_NUMBER,
            //    From = VONAGE_BRAND_NAME,
            //    Text = "A text message sent using the Vonage SMS API"
            //});


        }
    }
}
