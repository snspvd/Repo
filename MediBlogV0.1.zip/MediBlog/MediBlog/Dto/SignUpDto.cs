﻿using System.ComponentModel.DataAnnotations;

namespace MediBlog.Dto
{
    public class SignUpDto
    {
        [Required(ErrorMessage ="Enter First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Enter Last Name")]
        public string Lastname { get; set; }
        [Required(ErrorMessage = "Enter Email Address")]
        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "Enter Phone No")]
        public string PhoneNo { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Enter Confirm Password")]
        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "Enter Date of Birth")]
        public string DateOfBirth { get; set; }

        [Required(ErrorMessage = "Enter Gender")]
        public string Gender { get; set; }
        public string BloodGroup { get; set; }
        public bool IsBloodDonor { get; set; }
    }
}
