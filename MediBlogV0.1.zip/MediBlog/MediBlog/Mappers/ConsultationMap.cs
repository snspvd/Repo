﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;

namespace MediBlog.Mappers
{
    public class ConsultationMap:Profile
    {
        public ConsultationMap()
        {
            CreateMap<ConsultationDto, ConsultationModel>();
        }
    }
}
