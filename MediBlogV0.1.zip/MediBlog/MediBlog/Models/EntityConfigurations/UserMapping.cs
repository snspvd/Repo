﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace MediBlog.Models.EntityConfigurations
{
    public class UserMapping : IEntityTypeConfiguration<UserModel>
    {
        public void Configure(EntityTypeBuilder<UserModel> builder)
        {

            builder.ToTable("User");
            builder.Property(b => b.UserId).HasColumnName("UserId").IsRequired();
            builder.HasKey(b => b.UserId);
            builder.Property(b => b.FirstName).HasColumnName("FirstName").IsRequired();
            builder.Property(b => b.Lastname).HasColumnName("Lastname").IsRequired();
            builder.Property(b => b.EmailAddress).HasColumnName("EmailAddress").IsRequired();
            builder.Property(b => b.PhoneNo).HasColumnName("PhoneNo").IsRequired();
            builder.Property(b => b.Password).HasColumnName("Password").IsRequired();
            builder.Property(b => b.DateOfBirth).HasColumnName("DateOfBirth").IsRequired();
            builder.Property(b => b.Gender).HasColumnName("Gender").IsRequired();
            builder.Property(b => b.BloodGroup).HasColumnName("BloodGroup");
            builder.Property(b => b.IsBloodDonor).HasColumnName("IsBloodDonor").IsRequired();
            builder.Property(b => b.IsDeleted).HasColumnName("IsDeleted").IsRequired();
            builder.Property(b => b.CreationTime).HasColumnName("CreationTime");
            builder.Property(b => b.UpdationTime).HasColumnName("UpdationTime");
            builder.Property(b => b.Address).HasColumnName("Address");
            builder.Property(b => b.City).HasColumnName("City");
            builder.Property(b => b.State).HasColumnName("State");
        }
    }
}
