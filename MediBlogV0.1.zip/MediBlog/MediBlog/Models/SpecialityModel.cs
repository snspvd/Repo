﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MediBlog.Models
{
    public class SpecialityModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int SpecialityId { get; set; }
        [Required]
        public string SpecialityName { get; set; }
        public bool IsDeleted { get; set; }
        public string Description { get; set; }
    }
}
