﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using YoYo.Model.Dtos;
using YoYo.Model.Models;

namespace YoYo.Application.Services
{
    public class AthleteAppService:IAthleteAppService
    {
        public static List<AthleteModel> Athletes = new List<AthleteModel>()
        {
            new AthleteModel(){AthleteId=1,Name = "John Doe",HasWarned =false },
            new AthleteModel(){AthleteId=2,Name = "Will Smith",HasWarned =false },
            new AthleteModel(){AthleteId=3,Name = "Harvard",HasWarned =false },
            new AthleteModel(){AthleteId=4,Name = "Bill Hazard",HasWarned =false }
        };

        public static List<SpeedLevelDto> SpeedList = new List<SpeedLevelDto>();


        public AthleteAppService()
        {

        }

        public void UpdateAthleteStatus(int id, string status, int shuttleId, int speedLevel)
        {
            AthleteModel athlete = Athletes.FirstOrDefault(x => x.AthleteId == id);
            if (status == "warn")
            {
                athlete.HasWarned = true;
            }
            else if (status == "stop")
            {
                athlete.SpeedLevel = speedLevel;
                athlete.Shuttle = shuttleId;
            }
        }

    }
}
