﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYo.Application.Services
{
    public interface IAthleteAppService
    {
        void UpdateAthleteStatus(int id, string status, int shuttleId, int speedLevel);
    }
}
