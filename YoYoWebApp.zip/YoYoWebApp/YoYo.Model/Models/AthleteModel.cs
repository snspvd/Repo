﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YoYo.Model.Models
{
    public class AthleteModel
    {
        public int AthleteId { get; set; }
        public string Name { get; set; }
        public int SpeedLevel { get; set; }
        public int Shuttle { get; set; }
        public bool HasWarned { get; set; }
    }
}
