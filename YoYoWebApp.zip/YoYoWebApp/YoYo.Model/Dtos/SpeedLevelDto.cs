﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace YoYo.Model.Dtos
{
    public class SpeedLevelDto
    {
        [JsonProperty("AccumulatedShuttleDistance")]
        public int AccumulatedShuttleDistance { get; set; }

        [JsonProperty("SpeedLevel")]
        public int SpeedLevel { get; set; }

        [JsonProperty("ShuttleNo")]
        public int ShuttleNo { get; set; }

        [JsonProperty("Speed")]
        public double Speed { get; set; }

        [JsonProperty("LevelTime")]
        public string LevelTime { get; set; }

        [JsonProperty("CommulativeTime")]
        public string CommulativeTime { get; set; }

        [JsonProperty("StartTime")]
        public string StartTime { get; set; }

        [JsonProperty("ApproxVo2Max")]
        public string ApproxVo2Max { get; set; }


        public double WaitTime { get; set; }
        
        
    }
}
