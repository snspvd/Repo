﻿var waitTime = 0; index = 0; prevShuttle = null;

$(document).ready(function () {
    $("#athleteView").load("/FitnessTest/LoadAthletes");
})

function Update(item, status) {
    var data = { 'id': item, 'status': status, 'shuttleId': prevShuttle.shuttleNo, 'speedLevel': prevShuttle.speedLevel };
    console.log(data);
    $.ajax({
        url: 'http://localhost:63124/Fitnesstest/UpdateAthleteStatus',
        type: 'POST',
        data: data,
        success: function (result) {
            $("#athleteView").load("/FitnessTest/LoadAthletes");
        },
        error: function (ex) {
            console.log(ex);
        }
    });
}

function startTest() {
    getNextSpeed();
}

function millisToSeconds(millis) {
    var seconds = (millis / 1000);
    return (seconds);
}


function getNextSpeed() {
    $.ajax({
        url: 'http://localhost:63124/Fitnesstest/GetNextSpeedLevel',
        type: 'GET',
        data: { 'index': index },
        success: function (result) {
            index = result.index;
            if (index == -1) {
                waitTime = 0;
                $("#progBar").css("width", '100%');
                $("#secLeft").text(0);

            } else {
                waitTime = result.speed.waitTime
                prevShuttle = result.speed;
                $("#speedLevel").text(result.speed.speedLevel);
                $("#shuttle").text(result.speed.shuttleNo);

                $("#progBar").css("width", (index * 1.02).toString() + '%');
                $("#secLeft").text(millisToSeconds(waitTime));

                setTimeout(calculateDistance, waitTime, result.speed);
            }
        }
    });
}



//function calCulateTime() {

//    if (counter > 0) {
//        $("#secLeft").text(millisToSeconds(counter));
//        counter = counter - 1000;
//        setInterval(calCulateTime, 1000)
//    } else { clearInterval() }
//}

function calculateDistance(speed) {
    $("#timeProgress").text(speed.commulativeTime);
    $("#timeProgress").text(speed.commulativeTime);
    $("#distance").text(speed.accumulatedShuttleDistance);

    getNextSpeed();
}

