﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using YoYo.Application.Services;
using YoYo.Model.Dtos;
using YoYo.Model.Models;

namespace YoYoWebApp.Controllers
{
    public class FitnessTestController : Controller
    {

        private readonly IAthleteAppService _athleteService;

        public FitnessTestController(IAthleteAppService athleteAppService)
        {
            _athleteService = athleteAppService;
            GetSpeedList();
        }

        public IActionResult Index()
        {
            return View(AthleteAppService.Athletes);
        }
        public IActionResult LoadAthletes()
        {
            return PartialView("_AthleteListPartial", AthleteAppService.Athletes);
        }

        [HttpGet]
        public IActionResult GetNextSpeedLevel(int index)
        {
            int i = index + 1;
            if (AthleteAppService.SpeedList.Count() == index)
            {
                return Json(new { speed = new SpeedLevelDto(), index = -1 });
            }
            return Json(new { speed = AthleteAppService.SpeedList[index], index = i });
        }

        [HttpPost]
        public IActionResult UpdateAthleteStatus(int id, string status, int shuttleId, int speedLevel)
        {
            _athleteService.UpdateAthleteStatus(id, status, shuttleId, speedLevel);

            return new StatusCodeResult(200);
        }

        private void GetSpeedList()
        {
            string data = string.Empty;
            

            var assembly = AppDomain.CurrentDomain.GetAssemblies()
                 .Where(x => x.FullName.Contains($"YoYoWebApp"))
                 .Select(x => x).FirstOrDefault();

            Stream speedJson = assembly.GetManifestResourceNames().Where(x => x.Contains("fitnessrating_beeptest")).Select(y => assembly.GetManifestResourceStream(y)).FirstOrDefault();

            using (var text = new StreamReader(speedJson))
            {
                data = text.ReadToEnd();
            }

            List<SpeedLevelDto> speedLevels = JsonConvert.DeserializeObject<List<SpeedLevelDto>>(data);

            speedLevels.ForEach(x =>
            {
                x.WaitTime = (TimeSpan.Parse($"00:{ x.CommulativeTime}") - TimeSpan.Parse($"00:{x.StartTime}")).TotalMilliseconds;
            });

            AthleteAppService.SpeedList = speedLevels;

        }
        
    }
}