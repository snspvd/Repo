﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace DataLoad
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            ReadCsvFile();
        }

        public static void ReadCsvFile()
        {
            DataTable dtCsv = new DataTable();
            string Fulltext;
            
                using (StreamReader sr = new StreamReader(@"C:\Users\phani_suggala\Desktop\sample.csv"))
                {
                    while (!sr.EndOfStream)
                    {
                        Fulltext = sr.ReadToEnd().ToString(); //read full file text  
                        string[] rows = Fulltext.Split('\n'); //split full file text into rows  
                        for (int i = 0; i < rows.Count() - 1; i++)
                        {
                            string[] rowValues = rows[i].Split(','); //split each row with comma to get individual values  
                            {
                                if (i == 0)
                                {
                                    for (int j = 0; j < rowValues.Count(); j++)
                                    {
                                        dtCsv.Columns.Add(rowValues[j]); //add headers  
                                    }
                                }
                                else
                                {
                                    DataRow dr = dtCsv.NewRow();
                                    for (int k = 0; k < rowValues.Count(); k++)
                                    {
                                        dr[k] = rowValues[k].ToString();
                                    }
                                    dtCsv.Rows.Add(dr); //add other rows  
                                }
                            }
                        }
                    }
                }

            LoadData(dtCsv);
        }

        public static void LoadData(DataTable dt)
        {
            string connstr = "GIVE CONNECTION STRING DIRECTLY";
            SqlConnection con = new SqlConnection(connstr);
            con.Open();
            foreach (DataRow dr in dt.Rows)
            {
                SqlCommand cmd = new SqlCommand($"UPDATE TABLENAME SET Insurance ={dr[0].ToString()} WHERE REPID={dr[1].ToString()}", con);
                cmd.ExecuteNonQuery();
            }
            con.Close();
        }
    }
}
