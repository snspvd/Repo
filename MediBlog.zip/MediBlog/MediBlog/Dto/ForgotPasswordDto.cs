﻿namespace MediBlog.Dto
{
    public class ForgotPasswordDto
    {
        public string EmailAddress { get; set; }

    }
}
