﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MediBlog.Dto
{
    public class ConsultationDto
    {
        public int? ConsultationId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Please enter name")]
        public string PatientName { get; set; }
        
        [Required(ErrorMessage = "Please enter mobile no")]
        public string MobileNumber { get; set; }
        
        [Required(ErrorMessage = "Please enter email id")]
        public string EmailId { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public int Age { get; set; }
        
        [Required(ErrorMessage = "Please enter gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Please enter appointment date")]
        public DateTime AppointmentDate { get; set; }
        
        public string Description { get; set; }
        
        [Required(ErrorMessage = "Please select speciality")]
        public int SpecialityId { get; set; }

        public decimal ConsultationFee { get; set; }
    }
}
