﻿using System.Net;

namespace MediBlog.Dto
{
    public class ResponseDto
    {
        public HttpStatusCode ResultCode { get; set; }
        public object Result { get; set; }
        public object Error { get; set; }
    }

    public class SuccessDto
    {
        public string Message { get; set; }
    }
    public class ErrorDto
    {
        public string ErrorMessage { get; set; }
    }
}
