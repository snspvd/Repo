﻿using System.Net;

namespace MediBlog.Dto
{
    public class ResponseDto
    {
        public HttpStatusCode ResultCode { get; set; }
        public string Result { get; set; }
    }
}
