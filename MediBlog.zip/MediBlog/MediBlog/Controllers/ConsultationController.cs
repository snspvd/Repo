﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace MediBlog.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ConsultationController : ControllerBase
    {
        private IConfiguration _config;
        private readonly MediBlogContext _mediBlogContext;
        private readonly IMapper _mapper;

        public ConsultationController(
            IConfiguration config,
            MediBlogContext mediBlogContext,
            IMapper mapper)
        {
            _config = config;
            _mediBlogContext = mediBlogContext;
            _mapper = mapper;

        }

        [HttpPost]
        [Route("submitconsultation")]
        public IActionResult SubmitConsultation(ConsultationDto consultationDto)
        {

            ConsultationModel consultationModel = _mapper.Map<ConsultationModel>(consultationDto);
            if(_mediBlogContext.ConsultationModels.Any(x => x.ConsultationId == consultationModel.ConsultationId))
            {
                _mediBlogContext.ConsultationModels.Update(consultationModel);
            }
            else { _mediBlogContext.ConsultationModels.Add(consultationModel); }
            _mediBlogContext.SaveChanges();
            
            return Ok(new { });
        }
    }
}
