﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MediBlog.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ConsultationController : ControllerBase
    {
        private IConfiguration _config;
        private readonly MediBlogContext _mediBlogContext;
        private readonly IMapper _mapper;
        private readonly ILogger<LoginController> _logger;

        public ConsultationController(
            IConfiguration config,
            MediBlogContext mediBlogContext,
            IMapper mapper,
            ILogger<LoginController> logger)
        {
            _config = config;
            _mediBlogContext = mediBlogContext;
            _mapper = mapper;
            _logger = logger;


        }

        [HttpPost]
        [Route("submitconsultation")]
        public IActionResult SubmitConsultation([FromBody] ConsultationDto consultationDto)
        {
            _logger.LogInformation($"SubmitConsultation Method| {JsonConvert.SerializeObject(HttpContext.Request.Headers)}");
            _logger.LogInformation($"SubmitConsultation Reuqest Body| {JsonConvert.SerializeObject(consultationDto)}");

            ResponseDto response = new ResponseDto() { ResultCode = System.Net.HttpStatusCode.OK };
            try
            {
                ConsultationModel consultationModel = _mapper.Map<ConsultationModel>(consultationDto);
                if (_mediBlogContext.ConsultationModels.Any(x => x.ConsultationId == consultationModel.ConsultationId))
                {
                    _mediBlogContext.ConsultationModels.Update(consultationModel);
                }
                else { _mediBlogContext.ConsultationModels.Add(consultationModel); }
                _mediBlogContext.SaveChanges();
                response.Result = new { success = "Successfully Done" };

                return Ok(response);
            }
            catch (Exception ex)
            {
                response.ResultCode = System.Net.HttpStatusCode.BadRequest;
                response.Error = new { errorMessage = ex.Message };
                _logger.LogInformation($"SubmitConsultation Exception| {JsonConvert.SerializeObject(ex)}");
                return BadRequest(response);
            }

        }


        [HttpGet]
        [Route("getspecialities")]
        public IActionResult GetSpecialities()
        {
            _logger.LogInformation($"GetSpecialities Method| {JsonConvert.SerializeObject(HttpContext.Request.Headers)}");
            ResponseDto responseDto = new ResponseDto();
            try
            {
                var result = _mediBlogContext.SpecialityModels.Where(x => x.IsDeleted == false).ToList();
                responseDto = new ResponseDto() { Result = result, ResultCode = System.Net.HttpStatusCode.OK };
                
                _logger.LogInformation($"GetSpecialities Reuqest Body| {JsonConvert.SerializeObject(responseDto)}");
                return Ok(responseDto);
            }
            catch (Exception ex)
            {
                responseDto = new ResponseDto() { ResultCode = System.Net.HttpStatusCode.BadRequest, Error = new { errorMessage = ex.Message } };
                _logger.LogInformation($"GetSpecialities Exception| {JsonConvert.SerializeObject(ex)}");
                return BadRequest(responseDto);
            }
        }

        [HttpGet]
        [Route("getBloodDonors")]
        public IActionResult GetBloodDonors()
        {
            _logger.LogInformation($"GetBloodDonors Method| {JsonConvert.SerializeObject(HttpContext.Request.Headers)}");
            ResponseDto responseDto = new ResponseDto();
            try
            {
                var result = _mediBlogContext.UserModels.Where(x => x.IsDeleted == false && x.IsBloodDonor == true).ToList();
                responseDto = new ResponseDto() { Result = _mapper.Map<List<BloodDonorDto>>(result), ResultCode = System.Net.HttpStatusCode.OK };
                _logger.LogInformation($"GetBloodDonors Reuqest Body| {JsonConvert.SerializeObject(responseDto)}");
                return Ok(responseDto);
            }
            catch (Exception ex)
            {
                responseDto = new ResponseDto() { ResultCode = System.Net.HttpStatusCode.BadRequest, Error = new { errorMessage = ex.Message } };
                _logger.LogInformation($"GetBloodDonors Exception| {JsonConvert.SerializeObject(ex)}");
                return BadRequest(responseDto);
            }
        }

        [HttpGet]
        [Route("getConsultations")]
        public IActionResult GetConsultations(int userId)
        {
            ResponseDto responseDto = new ResponseDto();
            try
            {
                var result = _mediBlogContext.ConsultationModels.Where(x => x.UserId == userId).ToList();
                responseDto = new ResponseDto() { Result = _mapper.Map<List<ConsultationDto>>(result), ResultCode = System.Net.HttpStatusCode.OK };
                return Ok(responseDto);
            }
            catch (Exception ex)
            {
                responseDto = new ResponseDto() { ResultCode = System.Net.HttpStatusCode.BadRequest, Error = new { errorMessage = ex.Message } };
                return BadRequest(responseDto);
            }
        }

        [HttpGet]
        [Route("getConsultationDetailsById")]
        public IActionResult GetConsultationDetailsById(int consultationId)
        {
            ResponseDto responseDto = new ResponseDto();
            try
            {
                var result = _mediBlogContext.ConsultationModels.FirstOrDefault(x => x.ConsultationId == consultationId);
                responseDto = new ResponseDto() { Result = (_mapper.Map<ConsultationDto>(result)), ResultCode = System.Net.HttpStatusCode.OK };
                return Ok(responseDto);
            }
            catch (Exception ex)
            {
                responseDto = new ResponseDto() { ResultCode = System.Net.HttpStatusCode.BadRequest, Error = new { errorMessage = ex.Message } };
                return BadRequest(responseDto);
            }
        }
    }
}
