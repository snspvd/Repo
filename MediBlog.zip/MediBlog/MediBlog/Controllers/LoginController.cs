﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;


namespace MediBlog.Controllers
{

    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private IConfiguration _config;
        private readonly MediBlogContext _mediBlogContext;
        private readonly IMapper _mapper;
        private readonly ILogger<LoginController> _logger;

        public LoginController(IConfiguration config,
            MediBlogContext mediBlogContext,
            IMapper mapper,
            ILogger<LoginController> logger)
        {
            _config = config;
            _mediBlogContext = mediBlogContext;
            _mapper = mapper;
            _logger = logger;
        }


        [HttpPost]
        [Route("login")]
        public IActionResult Login([FromBody] LoginDto login)
        {
            _logger.LogInformation($"Login Method| {JsonConvert.SerializeObject(HttpContext.Request.Headers)}");
            _logger.LogInformation($"Login Reuqest Body| {JsonConvert.SerializeObject(login)}");
            IActionResult response = Unauthorized();
            var user = AuthenticateUser(login);
            ResponseDto responseDto = new ResponseDto();
            try
            {
                if (user != null)
                {
                    var tokenString = GenerateJSONWebToken(user);
                    var result = _mediBlogContext.UserModels.FirstOrDefault(x => x.PhoneNo == login.Username);
                    responseDto = new ResponseDto()
                    {
                        ResultCode = HttpStatusCode.OK,
                        Result = new
                        {
                            Token = tokenString,
                            EmailId = result.EmailAddress,
                            Phone = result.PhoneNo,
                            UserId = result.UserId,
                            FirstName = result.FirstName,
                            LastName = result.Lastname
                        }
                    };
                }
                else
                {

                    responseDto = new ResponseDto()
                    {
                        ResultCode = HttpStatusCode.BadRequest,
                        Error = new { errorMessage = "Couldn't find user" }
                    };

                    return BadRequest(responseDto);
                }

                return Ok(responseDto);
            }
            catch (Exception ex)
            {
                responseDto = new ResponseDto()
                {
                    ResultCode = HttpStatusCode.BadRequest,
                    Error = new { errorMessage = ex.Message }
                };

                return BadRequest(responseDto);
            }
        }





        [HttpPost]
        [Route("signup")]
        public IActionResult SignUp([FromBody] SignUpDto signupdto)
        {
            _logger.LogInformation($"SignUp Method| {JsonConvert.SerializeObject(HttpContext.Request.Headers)}");
            _logger.LogInformation($"SignUp Reuqest Body| {JsonConvert.SerializeObject(signupdto)}");
            ResponseDto responseDto = new ResponseDto();
            try
            {
                bool isExistingUser = _mediBlogContext.UserModels.Any(x => (x.EmailAddress == signupdto.EmailAddress || x.PhoneNo == signupdto.PhoneNo));
                if (isExistingUser)
                {
                    responseDto = new ResponseDto()
                    {
                        ResultCode = HttpStatusCode.BadRequest,
                        Error = new { errorMessage = "User already exits" }
                    };
                    return BadRequest(responseDto);
                };


                UserModel userModel = _mapper.Map<UserModel>(signupdto);

                userModel.CreationTime = DateTime.Now;
                userModel.UpdationTime = DateTime.Now;
                _mediBlogContext.UserModels.Add(userModel);
                _mediBlogContext.SaveChanges();

                responseDto = new ResponseDto()
                {
                    ResultCode = HttpStatusCode.OK,
                    Result = new { success = "Successfully Done" }
                };

                return Ok(responseDto);
            }
            catch (Exception ex)
            {
                responseDto = new ResponseDto()
                {
                    ResultCode = HttpStatusCode.BadRequest,
                    Error = new { errorMessage = ex.Message }
                };

                return BadRequest(responseDto);
            }
        }

        [HttpPost]
        [Route("forgotpassword")]
        public IActionResult ForGotPassword([FromBody] ForGotDto forGotDto)
        {
            ResponseDto responseDto = new ResponseDto();

            var dbUser = _mediBlogContext.UserModels.FirstOrDefault(x => x.EmailAddress == forGotDto.EmailAddress || x.PhoneNo == forGotDto.Username);
            if (dbUser != null)
            {
                SendSms obj = new SendSms();
                obj.Execute();

                UserModel userModel = _mapper.Map<UserModel>(dbUser);

                userModel.UpdationTime = DateTime.Now;
                _mediBlogContext.UserModels.Update(userModel);
                _mediBlogContext.SaveChanges();
            }
            else
            {
                return BadRequest(responseDto);
            }

            return Ok(responseDto);
        }
        private string GenerateJSONWebToken(LoginDto userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, userInfo.Username),
                new Claim(JwtRegisteredClaimNames.Email, userInfo.EmailAddress),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddMinutes(20),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private LoginDto AuthenticateUser(LoginDto user)
        {
            var dbUser = _mediBlogContext.UserModels.FirstOrDefault(x => x.PhoneNo == user.Username && x.Password == user.Password);

            return dbUser == null ? null : user;
        }
    }
}
