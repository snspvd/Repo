﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;

namespace MediBlog.Mappers
{
    public class UserProfileMap: Profile
    {
        public UserProfileMap()
        {
            CreateMap<SignUpDto, UserModel>();
        }
    }
}
