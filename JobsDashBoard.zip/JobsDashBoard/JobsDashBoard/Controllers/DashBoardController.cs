﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using JobsDashBoard.Models;
using System.Reflection;
using System.IO;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;


namespace JobsDashBoard.Controllers
{
    public class DashBoardController : Controller
    {
        private string connection;
        public DashBoardController(IConfiguration config)
        {
            connection = config.GetConnectionString("DefaultConnection");
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult LoadJobs(string search)
        {
            List<JobModel> jobs = new List<JobModel>();
            using (OracleConnection con = new OracleConnection(connection))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {

                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandText = "select * from <Tablename> where <j0obname> = :jobName";
                    OracleParameter id = new OracleParameter("jobName", search);
                    cmd.Parameters.Add(id);
                    OracleDataReader reader = cmd.ExecuteReader();

                    JobModel job;
                    while (reader.Read())
                    {
                        job = new JobModel()
                        {
                            BusinessUnit = reader.GetString(0),
                            JobName = reader.GetString(0),
                            ScheduleDate = reader.GetDateTime(1),
                            LastRunDateTime = reader.GetDateTime(2),
                            NextRunDateTime = reader.GetDateTime(3),
                            ScheduledByUser = reader.GetString(4),
                            Status = reader.GetString(5),
                            Performance = reader.GetString(6),
                            Parameters = reader.GetString(7),
                            LastRuns = reader.GetString(8),

                        };
                        jobs.Add(job);
                    }
                    reader.Dispose();
                }
            }
            return Json(new { data = JsonConvert.SerializeObject(jobs) });
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    public class JobModel
    {
        public string BusinessUnit { get; set; }
        public string JobName { get; set; }
        public DateTime ScheduleDate { get; set; }
        public DateTime LastRunDateTime { get; set; }
        public DateTime NextRunDateTime { get; set; }
        public string ScheduledByUser { get; set; }
        public string Status { get; set; }
        public string Performance { get; set; }
        public string Parameters { get; set; }
        public string LastRuns { get; set; }
    }

}
