﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using JobsDashBoard.Models;
using System.Reflection;
using System.IO;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace JobsDashBoard.Controllers
{
    public class DashBoardController : Controller
    {
        private string connection;
        public DashBoardController(IConfiguration config)
        {
            connection = config.GetConnectionString("DefaultConnection");
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult LoadJobs()
        {
            var assembly = Assembly.GetExecutingAssembly();
            string filename = assembly.GetManifestResourceNames().Single(str => str.EndsWith("data.txt"));
            var stream = assembly.GetManifestResourceStream(filename);
            byte[] bytes = new byte[stream.Length];
            stream.Read(bytes, 0, bytes.Length);
            MemoryStream ms = new MemoryStream(bytes);
            StreamReader reader = new StreamReader(ms);
            string text = reader.ReadToEnd();

            return Json(new { data = JsonConvert.DeserializeObject(text) });
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
